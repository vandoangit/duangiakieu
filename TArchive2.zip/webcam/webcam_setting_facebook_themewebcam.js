/* * ***************************************************************************
 
 Ghi chú:hoàn thành ngày 27-07-2015
 Copyright :Hồ Minh Trí
 
 * ************************************************************************** */

// Webcame width,height > 382
var webcam_width=480;
var webcam_height=400;
var script_webcam_main="#webcam_facebook_object";
var webcam_snapshot_image_value="#webcam_facebook .webcam_facebook_image img";